print("Hello World!");
print('python program');
