print("My name is Will Throm.\nI am a sophmore CS major here at Mizzou.\nSometimes I unicycle to get around campus.\nMy favorite ice cream flavor is Cookie Dough.")
